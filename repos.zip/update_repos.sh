#!/bin/bash

# 下载repos.zip文件
wget -O /tmp/repos.zip http://example.com/repos.zip

# 确保下载成功
if [ $? -ne 0 ]; then
    echo "文件下载失败！"
    exit 1
fi

# 解压文件到临时目录
unzip -o /tmp/repos.zip -d /tmp

# 确保解压成功
if [ $? -ne 0 ]; then
    echo "文件解压失败！"
    exit 1
fi

# 备份原有的.repo文件
mkdir -p /etc/yum.repos.d/backup
mv /etc/yum.repos.d/*.repo /etc/yum.repos.d/backup/

# 替换原有的.repo文件
mv /tmp/*.repo /etc/yum.repos.d/

# 清理临时文件
rm -f /tmp/repos.zip
rm -rf /tmp/*.repo

echo "repo文件更新成功！"
